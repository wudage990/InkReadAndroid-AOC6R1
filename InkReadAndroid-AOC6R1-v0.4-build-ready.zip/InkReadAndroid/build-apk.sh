#!/usr/bin/env bash
set -euo pipefail
# Requires JDK 17, Android SDK platform 35, Android build-tools, and Gradle 8.7.
gradle --no-daemon :app:assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
