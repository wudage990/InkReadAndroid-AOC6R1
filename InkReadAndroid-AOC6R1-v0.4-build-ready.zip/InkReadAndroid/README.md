# 墨阅 InkRead — AOC 6R1 / Android 8.1

本版为面向 AOC 6R1（Android 8.1 / API 27）的原生 Kotlin 项目迭代版。

## 0.3 更新
- PDF 页面转换为 16 级灰阶（软件侧亮度量化），更贴合 AOC 6R1 灰阶屏
- TXT / EPUB 图片使用灰度显示，正文采用纯黑白高对比配色
- 新增行距循环调节（1.6 / 1.85 / 2.1），设置自动记忆

## 已有功能
- 本地书架：导入的文件保存在最近书架列表（持久化 URI 授权）
- 最近书籍点击继续阅读
- TXT / EPUB 阅读滚动位置自动保存与恢复
- PDF 页码自动保存与恢复
- 全局字体大小记忆，阅读页 A− / A＋ 调整
- PDF 位图宽度限制为屏幕宽度与 680px 的较小值，降低内存压力
- 音量键和方向键翻页

## 支持格式
- TXT：UTF-8
- EPUB：基础 OPF manifest/spine 章节读取
- PDF：Android PdfRenderer 按页显示

## 构建
Android Studio 打开项目，使用 JDK 17、Android SDK 35，Gradle Sync 后执行 Build > Build APK(s)。
命令行可运行 `./gradlew assembleDebug`。
APK 输出位置：`app/build/outputs/apk/debug/app-debug.apk`。

## 重要说明
- 当前 EPUB 解析为轻量实现，复杂 EPUB3 导航、CSS、加密、脚注、跨章节分页等尚未完整支持。
- TXT 暂按 UTF-8 读取，GBK/GB18030 编码识别待加入。
- 水墨屏全刷/局刷/波形控制通常需要厂商接口；当前没有未经验证地调用私有 API。请在 AOC 6R1 实机上确认刷新设置和按键映射。
- 16 级灰阶是软件渲染量化，不等于调用了设备硬件刷新波形；全刷/局刷仍由系统或厂商固件控制。
- 尚未在真实 AOC 6R1 上编译安装与测试，不能宣称已验证。


## 0.4 构建准备
- 应用版本号更新为 0.4.0。
- `targetSdk` 调整为 28（Android 9），保留 `minSdk` 27（Android 8.1），以照顾 Android 8.1 设备上的旧系统兼容性。
- 新增 `.github/workflows/android-apk.yml`：推送到 GitHub 的 main/master 分支或手动运行工作流时，在云端构建 debug APK，并将 APK 作为 Actions Artifact 保存 30 天。
- 云端构建需要 JDK 17、Gradle 8.7 和 Android SDK Platform 35。debug APK 由 Android Gradle Plugin 自动使用 debug key 签名，可用于测试安装；正式上架或长期分发应另行配置自己的 release 签名密钥。

### 如何取得 APK
1. 将本项目上传到自己的 GitHub 仓库。
2. 打开仓库的 Actions 页面，运行 `Build Android APK` 工作流（或向 main/master 推送代码）。
3. 工作流成功后，在该次运行页面的 Artifacts 区域下载 `InkRead-AOC6R1-debug-apk`，解压得到 `app-debug.apk`。
4. 将 APK 传到 AOC 6R1 安装。首次安装若系统拦截，请在系统设置中允许文件管理器安装未知来源应用。

**当前限制：** 此开发环境没有 Android SDK、Gradle，也无法连接外网下载构建依赖，因此这里不能真实执行 Android 编译，尚不能提供已验证的 APK。工作流文件已加入项目，供有网络的 GitHub Actions 云端执行构建。
