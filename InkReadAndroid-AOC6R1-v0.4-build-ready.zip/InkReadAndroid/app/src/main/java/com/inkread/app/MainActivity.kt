package com.inkread.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("inkread", MODE_PRIVATE) }
    private val openBook = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            addBook(it)
            openReader(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        renderShelf()
    }

    private fun openReader(uri: Uri) {
        startActivity(Intent(this, ReaderActivity::class.java).setData(uri))
    }

    private fun addBook(uri: Uri) {
        val name = displayName(uri)
        val list = readBooks()
        val old = (0 until list.length()).map { list.optJSONObject(it) }
            .filterNotNull().filter { it.optString("uri") != uri.toString() }
        val item = JSONObject().put("uri", uri.toString()).put("name", name)
        val updated = JSONArray().put(item)
        old.forEach { if (updated.length() < 100) updated.put(it) }
        prefs.edit().putString("books", updated.toString()).apply()
    }

    private fun readBooks(): JSONArray = try { JSONArray(prefs.getString("books", "[]")) } catch (_: Exception) { JSONArray() }

    private fun displayName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "未命名书籍"
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0) ?: name
        }
        return name
    }

    private fun renderShelf() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
            setBackgroundColor(0xFFF4F1E8.toInt())
        }
        outer.addView(TextView(this).apply {
            text = "墨阅"; textSize = 32f; gravity = Gravity.CENTER
            setTextColor(0xFF111111.toInt()); typeface = android.graphics.Typeface.SERIF
            setPadding(0, 18, 0, 4)
        })
        outer.addView(TextView(this).apply {
            text = "AOC 6R1 · 静心阅读"; textSize = 14f; gravity = Gravity.CENTER
            setTextColor(0xFF555555.toInt()); setPadding(0, 0, 0, 18)
        })
        outer.addView(Button(this).apply {
            text = "＋ 导入书籍（EPUB / TXT / PDF）"; isAllCaps = false
            setOnClickListener { openBook.launch(arrayOf("application/epub+zip", "text/plain", "application/pdf", "*/*")) }
        }, LinearLayout.LayoutParams(-1, -2))
        outer.addView(TextView(this).apply {
            text = "我的书架"; textSize = 20f; typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(0xFF111111.toInt()); setPadding(2, 24, 0, 10)
        })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val books = readBooks()
        if (books.length() == 0) {
            list.addView(TextView(this).apply {
                text = "书架还是空的。点击上方导入一本电子书吧。"
                textSize = 16f; setTextColor(0xFF555555.toInt()); setPadding(4, 18, 4, 18)
            })
        } else {
            for (i in 0 until books.length()) {
                val item = books.optJSONObject(i) ?: continue
                val uri = Uri.parse(item.optString("uri"))
                val name = item.optString("name", "未命名书籍")
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(12, 12, 12, 12)
                    setBackgroundColor(0xFFFFFFFF.toInt())
                }
                row.addView(TextView(this).apply {
                    text = name; textSize = 18f; typeface = android.graphics.Typeface.SERIF
                    setTextColor(0xFF111111.toInt())
                })
                row.addView(TextView(this).apply {
                    text = "点击继续阅读"; textSize = 13f; setTextColor(0xFF555555.toInt())
                })
                row.setOnClickListener {
                    try { openReader(uri) } catch (_: Exception) {
                        android.widget.Toast.makeText(this, "文件暂时无法访问，请重新导入", android.widget.Toast.LENGTH_LONG).show()
                    }
                }
                list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
            }
        }
        val scroll = ScrollView(this).apply { addView(list) }
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)
    }
}
