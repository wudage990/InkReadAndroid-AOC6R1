package com.inkread.app

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.jsoup.Jsoup
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.zip.ZipFile

class ReaderActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("inkread", MODE_PRIVATE) }
    private var pdf: PdfRenderer? = null
    private var pdfFd: android.os.ParcelFileDescriptor? = null
    private var pdfPageIndex = 0
    private lateinit var content: LinearLayout
    private lateinit var pageLabel: TextView
    private lateinit var image: ImageView
    private lateinit var web: WebView
    private var isPdf = false
    private var fontSize = 21
    private val lineSpacings = listOf(1.6f, 1.85f, 2.1f)
    private var lineSpacingIndex = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val uri = intent.data ?: run { finish(); return }
        fontSize = prefs.getInt("fontSize", 21).coerceIn(16, 32)
        lineSpacingIndex = prefs.getInt("lineSpacingIndex", 1).coerceIn(0, lineSpacings.lastIndex)
        val name = queryName(uri).lowercase()
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(0xFFECEAE2.toInt()) }
        toolbar.addView(Button(this).apply { text = "书架"; isAllCaps = false; setOnClickListener { finish() } })
        pageLabel = TextView(this).apply {
            text = "墨阅"; textSize = 13f; setTextColor(Color.BLACK)
            gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(8, 0, 8, 0)
        }
        toolbar.addView(pageLabel, LinearLayout.LayoutParams(0, -1, 1f))
        toolbar.addView(Button(this).apply { text = "A−"; isAllCaps = false; setOnClickListener { changeFont(-1) } })
        toolbar.addView(Button(this).apply { text = "A＋"; isAllCaps = false; setOnClickListener { changeFont(1) } })
        toolbar.addView(Button(this).apply {
            text = "行距"; isAllCaps = false
            setOnClickListener { cycleLineSpacing() }
        })
        content.addView(toolbar, LinearLayout.LayoutParams(-1, -2))
        setContentView(content)
        when {
            name.endsWith(".pdf") -> openPdf(uri)
            name.endsWith(".epub") -> openEpub(uri)
            else -> openText(uri)
        }
    }

    private fun queryName(uri: Uri): String {
        var result = "book.txt"
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) result = it.getString(0) ?: result
        }
        return result
    }

    private fun openText(uri: Uri) {
        val text = contentResolver.openInputStream(uri)?.use {
            BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText()
        } ?: "无法读取文件"
        showHtml("<article>${escapeHtml(text).replace("\n", "<br/>")}</article>", "TXT", uri)
    }

    private fun openEpub(uri: Uri) {
        try {
            val temp = cacheDir.resolve("book-${System.currentTimeMillis()}.epub")
            contentResolver.openInputStream(uri)?.use { input -> temp.outputStream().use { output -> input.copyTo(output) } }
            ZipFile(temp).use { zip ->
                val containerEntry = zip.getEntry("META-INF/container.xml") ?: error("EPUB 缺少 container.xml")
                val container = zip.getInputStream(containerEntry).bufferedReader().readText()
                val rootFile = Regex("full-path=[\\"']([^\\"']+)[\\"']").find(container)?.groupValues?.get(1)
                    ?: error("EPUB 缺少 OPF 文件路径")
                val base = rootFile.substringBeforeLast("/", "")
                val opfEntry = zip.getEntry(rootFile) ?: error("找不到 OPF 文件")
                val opf = zip.getInputStream(opfEntry).bufferedReader().readText()
                val doc = Jsoup.parse(opf, "", org.jsoup.parser.Parser.xmlParser())
                val byId = doc.select("manifest item").associate { it.attr("id") to it.attr("href") }
                val chapters = doc.select("spine itemref").mapNotNull { ref ->
                    val href = byId[ref.attr("idref")] ?: return@mapNotNull null
                    val path = if (base.isEmpty()) href else "$base/$href"
                    val entry = zip.getEntry(path) ?: zip.getEntry(path.replace("%20", " "))
                    entry?.let { zip.getInputStream(it).bufferedReader().readText() }
                }
                val body = chapters.joinToString("\n<hr/>\n") { Jsoup.parse(it).body().html() }
                showHtml(body.ifBlank { "这本 EPUB 暂无可显示内容" }, "EPUB", uri)
            }
            temp.delete()
        } catch (e: Exception) {
            showHtml("EPUB 解析失败：${escapeHtml(e.message ?: "未知错误")}", "EPUB", uri)
        }
    }

    private fun showHtml(body: String, kind: String, uri: Uri) {
        val savedY = prefs.getInt("pos_${uri}", 0)
        val html = """<html><head><meta name="viewport" content="width=device-width, initial-scale=1">
            <style>
            body{background:#fff;color:#000;font-family:serif;font-size:${fontSize}px;line-height:${lineSpacings[lineSpacingIndex]};padding:5%;margin:0}
            p{ text-indent:2em; margin:0 0 1em } h1,h2,h3{line-height:1.4;color:#000}
            img{max-width:100%;height:auto;filter:grayscale(1);image-rendering:auto}
            a{color:#000;text-decoration:underline}
            </style></head><body>$body
            <script>window.onload=function(){window.scrollTo(0, $savedY);};
            window.onscroll=function(){try{
              var y=Math.round(window.scrollY);
              var max=Math.max(0,document.documentElement.scrollHeight-window.innerHeight);
              InkRead.save(y,max);
            }catch(e){}};</script>
            </body></html>"""
        web = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled = true
            settings.defaultTextEncodingName = "UTF-8"
            addJavascriptInterface(ScrollBridge(uri), "InkRead")
            webViewClient = WebViewClient()
            loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        }
        content.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        pageLabel.text = "阅读中 · $kind"
    }

    private inner class ScrollBridge(private val uri: Uri) {
        @android.webkit.JavascriptInterface
        fun save(y: Int, max: Int) {
            val safeY = y.coerceAtLeast(0)
            prefs.edit().putInt("pos_${uri}", safeY)
                .putInt("percent_${uri}", if (max > 0) ((safeY * 100L) / max).toInt().coerceIn(0, 100) else 0)
                .apply()
        }
    }

    private fun cycleLineSpacing() {
        lineSpacingIndex = (lineSpacingIndex + 1) % lineSpacings.size
        prefs.edit().putInt("lineSpacingIndex", lineSpacingIndex).apply()
        if (::web.isInitialized) {
            web.evaluateJavascript("document.body.style.lineHeight='${lineSpacings[lineSpacingIndex]}';", null)
        }
        Toast.makeText(this, "行距：${lineSpacings[lineSpacingIndex]}", Toast.LENGTH_SHORT).show()
    }

    private fun changeFont(delta: Int) {
        fontSize = (fontSize + delta).coerceIn(16, 32)
        prefs.edit().putInt("fontSize", fontSize).apply()
        if (::web.isInitialized) web.evaluateJavascript(
            "document.body.style.fontSize='${fontSize}px';", null
        )
    }

    private fun openPdf(uri: Uri) {
        try {
            pdfFd = contentResolver.openFileDescriptor(uri, "r") ?: error("无法打开 PDF")
            pdf = PdfRenderer(pdfFd!!)
            isPdf = true
            pdfPageIndex = prefs.getInt("pdf_${uri}", 0).coerceIn(0, (pdf!!.pageCount - 1).coerceAtLeast(0))
            image = ImageView(this).apply {
                setBackgroundColor(Color.WHITE); adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            content.addView(image, LinearLayout.LayoutParams(-1, 0, 1f))
            val controls = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER }
            controls.addView(Button(this).apply { text = "上一页"; isAllCaps = false; setOnClickListener { renderPdf(pdfPageIndex - 1) } })
            controls.addView(Button(this).apply { text = "下一页"; isAllCaps = false; setOnClickListener { renderPdf(pdfPageIndex + 1) } })
            content.addView(controls)
            renderPdf(pdfPageIndex)
        } catch (e: Exception) {
            Toast.makeText(this, "PDF 打开失败：${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun renderPdf(index: Int) {
        val renderer = pdf ?: return
        if (index !in 0 until renderer.pageCount) return
        val page = renderer.openPage(index)
        val width = minOf(resources.displayMetrics.widthPixels, 680)
        val height = (width.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(Color.WHITE)
        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        page.close()
        applySixteenLevelGrayscale(bitmap)
        image.setImageBitmap(bitmap)
        pdfPageIndex = index
        val uri = intent.data
        if (uri != null) prefs.edit().putInt("pdf_${uri}", index).apply()
        pageLabel.text = "PDF · ${index + 1}/${renderer.pageCount}"
    }

    // Quantize luminance to 16 evenly spaced gray levels (0..255).
    // This is a display-side conversion; hardware refresh waveforms remain device-controlled.
    private fun applySixteenLevelGrayscale(bitmap: Bitmap) {
        val pixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        for (i in pixels.indices) {
            val color = pixels[i]
            val r = Color.red(color)
            val g = Color.green(color)
            val b = Color.blue(color)
            val luminance = (299 * r + 587 * g + 114 * b) / 1000
            val level = ((luminance * 15 + 127) / 255).coerceIn(0, 15)
            val gray = (level * 255 + 7) / 15
            pixels[i] = Color.rgb(gray, gray, gray)
        }
        bitmap.setPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (isPdf && (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)) { renderPdf(pdfPageIndex + 1); return true }
        if (isPdf && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_DPAD_LEFT)) { renderPdf(pdfPageIndex - 1); return true }
        if (!isPdf && (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)) {
            if (::web.isInitialized) web.pageDown(true); return true
        }
        if (!isPdf && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_DPAD_LEFT)) {
            if (::web.isInitialized) web.pageUp(true); return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        pdf?.close()
        pdfFd?.close()
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }

    private fun escapeHtml(value: String) = value.replace("&", "&amp;").replace("<", "&lt;")
        .replace(">", "&gt;").replace("\\"", "&quot;").replace("'", "&#39;")
}
