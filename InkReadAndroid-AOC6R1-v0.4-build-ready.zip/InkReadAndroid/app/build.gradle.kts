plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.inkread.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.inkread.app"
        minSdk = 27
        targetSdk = 28
        versionCode = 4
        versionName = "0.4.0"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("org.jsoup:jsoup:1.18.3")
}
